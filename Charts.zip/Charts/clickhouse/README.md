## Template Variables, these are leveraged to construct the keeper hosts FQDNS, database names, typically you don't have to change these values

galileo_infra:
  clickhouse
    override_domain: <KubernetesCustomDomain |default .svc.cluster.local>
    cluster:
      resources: {} 
    keeper:
      resources: {}
      nameSpace: <KubernetesNamespace |default CurrentNamespace>

galileo_config:
  clickhouse_db_name: <CustomClickHouseDbName |default galileo>
  clickhouse_cluster_name: <CustomClickHouseClusterName |default clickhouse>
  clickhouse_keeper_name: <CustomClickHouseKeeperName |default clickhouse-keeper>
