## Create internal CA , Server and Client Certs

### To enable TLS between services, we would leverage this CA and Certs

### How it works ?

On deploy , the K8s job (one time job) will check for the secret `galileo-internal-certs`, if this does not exist, the job will create the required CA and certs and create the K8s secret.

* This is a onetime job and running it again will not overwirte existing secret

### Services which can be enabled with TLS
* RabbitMQ - TLS cert is created as per operator Spec
* ClickHouse Keeper
* ClickHouse Cluster
* Self Managed PostgreSQL
* API (if UI to API calls should need TLS)
* Ideally any services within the Kubernetes Namespace can utilize these certs 

### Adding new cert (if needed)
Edit the script and call the function
`create_cert <k8s_secret_name> <k8s_secret_type> <cert_type> '<dns_names_for_cert>'`

```
Example: Server Cert
create_cert galileo-postgres-tls generic server 'DNS:postgres-v16,DNS:postgres-v16.{{.Release.Namespace}}'

Example: Client Cert
create_cert galileo-postgres-client-tls generic client NONE

Example K8s TLS Secret
create_cert galileo-generic-tls tls server 'DNS:*.{{.Release.Namespace}}.svc.cluster.local,DNS:*.{{.Release.Namespace}}'

```

### Server and Client certs

* Server cert is wildcard so any service within the namespace will work
* Always refer to the CA bundle when accessing the service to make it fully compliant with security standards
* Client Cert can / will be used between services where mTLS can be enable (not mandatory but good to have)

### Wildcard 

* The server cert will have SAN's `*.<namespace>.svc.cluster.local` and `*.<namesapce>` , example `*.galileo.svc.cluster.local` , `*.galileo`

* If you prefer to add additional SAN's , please udpate `scripts/create-certs.sh` under `alt_names` section

### Creating the certs

`helm upgrade --install galileo-tls galileo-tls -n <namespace>` 

