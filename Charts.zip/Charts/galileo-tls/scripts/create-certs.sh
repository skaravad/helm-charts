#!/bin/bash
# generate aes encrypted private key
export CA_NAME=galileo-internal-ca
export NAMESPACE={{.Release.Namespace}}
export WORK_DIR=/tmp/run
export RECREATE_CERTS=YES
cd $WORK_DIR

create_ca () {
echo "Creating Internal CA"
openssl genrsa  -out $CA_NAME.key 2048
openssl dhparam -out dhparams.pem 2048
openssl req -x509 -new -key $CA_NAME.key -sha256 -days 1826 -out $CA_NAME.crt \
-subj '/CN=Galileo Internal Root CA/C=US/ST=California/L=San Francisco/O=Platform'
kubectl create secret generic $CA_NAME --from-file=ca.crt=$CA_NAME.crt --from-file=ca.key=$CA_NAME.key \
--from-file=dhparams.pem=dhparams.pem
kubectl create secret generic ${CA_NAME}-cert --from-file=ca.crt=$CA_NAME.crt
}

create_cert () {
CERT_NAME=$1
SECRET_TYPE=$2
CERT_TYPE=$3
DNS_NAMES=$4

# Check if Secret Exists
if [[ "$RECREATE_CERTS" == "$FORCE_CERT" ]]; then
  kubectl delete secret $CERT_NAME
fi

kubectl get secret $CERT_NAME -n $NAMESPACE
if [ $? -ne 0 ]; then

# Create CSR
echo "$CERT_NAME does not exist .. creating"
openssl req -new -out $CERT_NAME.csr -newkey rsa:2048 -keyout $CERT_NAME.key \
-subj '/CN='${CERT_NAME}'/C=US/ST=California/L=San Fransisco/O=Platform' -nodes

## Create openssl.conf
cat > $CERT_NAME.v3.ext << EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
EOF
if [[ "$CERT_TYPE" = "server" ]]; then
cat >> $CERT_NAME.v3.ext << EOF
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
extendedKeyUsage = serverAuth
subjectAltName = $DNS_NAMES
EOF
else
cat >> $CERT_NAME.v3.ext << EOF
keyUsage = digitalSignature, nonRepudiation, keyEncipherment
extendedKeyUsage = clientAuth
EOF
fi

### Sign the Cert
echo "Signing $CERT_NAME"
openssl x509 -req -in $CERT_NAME.csr -CA $CA_NAME.crt -CAkey $CA_NAME.key -CAcreateserial \
-out $CERT_NAME.crt -days 730 -sha256 -extfile $CERT_NAME.v3.ext
cat $CA_NAME.crt >> $CERT_NAME.crt

# Create K8s Secret
  if [[ "$SECRET_TYPE" == "tls" ]]; then
    kubectl create secret tls $CERT_NAME --cert=$CERT_NAME.crt --key=$CERT_NAME.key
  else
      if  [[ "$CERT_TYPE" = "server" ]]; then
        kubectl create secret generic $CERT_NAME --from-file=ca.crt=$CA_NAME.crt --from-file=tls.crt=$CERT_NAME.crt --from-file=tls.key=$CERT_NAME.key --from-file=dhparams.pem=dhparams.pem
      else
        kubectl create secret generic $CERT_NAME --from-file=ca.crt=$CA_NAME.crt --from-file=tls.crt=$CERT_NAME.crt --from-file=tls.key=$CERT_NAME.key
      fi
  fi
## End
else
  echo "$CERT_NAME already exists"
fi

}

create_get_ca_secret () {
  kubectl get secret $CA_NAME -n $NAMESPACE
  if [ $? -ne 0 ]; then
    echo "$CA_NAME Does not exist"
    create_ca
  else
    kubectl get secret $CA_NAME -o jsonpath='{.data.ca\.crt}' |base64 -d > $CA_NAME.crt
    kubectl get secret $CA_NAME -o jsonpath='{.data.ca\.key}' |base64 -d > $CA_NAME.key
    kubectl get secret $CA_NAME -o jsonpath='{.data.dhparams\.pem}' |base64 -d > dhparams.pem
  fi
}

create_get_ca_secret

# RMQ Cert
create_cert galileo-rabbitmq-tls tls server 'DNS:rabbitmq-cluster.{{.Release.Namespace}}.svc.cluster.local,DNS:*.rabbitmq-cluster-nodes.{{.Release.Namespace}}.svc.cluster.local,DNS:rabbitmq-cluster.{{.Release.Namespace}}'

# Wilcard Cert for all Services
create_cert galileo-server-tls generic server 'DNS:*.{{.Release.Namespace}},DNS:*.{{.Release.Namespace}}.svc.cluster.local'

# Client Cert
create_cert galileo-client-tls generic client NA
